function alerta(){

    console.log("hiciste click en el botón de la motivación, guap@");

    alert("sé feliz y que nadie te arrebate esa felicidad. Confía en tí mismo y sobre todo, ten ánimo :D")

}